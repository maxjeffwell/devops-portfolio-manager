{{/*
Common deployment template for portfolio applications
Usage:
  {{- include "portfolio-common.deployment" (dict "component" "api" "context" $) }}
  {{- include "portfolio-common.deployment" (dict "component" "client" "context" $) }}
*/}}
{{- define "portfolio-common.deployment" -}}
{{- $component := .component }}
{{- $ := .context }}
{{- $componentConfig := index $.Values.image $component }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "portfolio-common.fullname" $ }}-{{ $component }}
  labels:
    app: {{ include "portfolio-common.name" $ }}-{{ $component }}
    component: {{ $component }}
    {{- include "portfolio-common.labels" $ | nindent 4 }}
spec:
  {{- if not $.Values.autoscaling.enabled }}
  replicas: {{ $.Values.replicaCount | default 2 }}
  {{- end }}
  {{- if $.Values.strategy }}
  strategy:
    {{- toYaml $.Values.strategy | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      app: {{ include "portfolio-common.name" $ }}-{{ $component }}
      component: {{ $component }}
      {{- include "portfolio-common.selectorLabels" $ | nindent 6 }}
  template:
    metadata:
      annotations:
        {{- include "portfolio-common.annotations" $ | nindent 8 }}
      labels:
        app: {{ include "portfolio-common.name" $ }}-{{ $component }}
        component: {{ $component }}
        portfolio: "true"
        {{- include "portfolio-common.selectorLabels" $ | nindent 8 }}
    spec:
      {{- include "portfolio-common.imagePullSecrets" $ | nindent 6 }}
      serviceAccountName: {{ include "portfolio-common.serviceAccountName" $ }}
      {{- if $.Values.priorityClassName }}
      priorityClassName: {{ $.Values.priorityClassName }}
      {{- end }}
      {{- include "portfolio-common.podSecurityContext" $ | nindent 6 }}
      {{- if $.Values.terminationGracePeriodSeconds }}
      terminationGracePeriodSeconds: {{ $.Values.terminationGracePeriodSeconds }}
      {{- end }}
      {{- if $.Values.dnsPolicy }}
      dnsPolicy: {{ $.Values.dnsPolicy }}
      {{- end }}
      {{- if $.Values.dnsConfig }}
      dnsConfig:
        {{- toYaml $.Values.dnsConfig | nindent 8 }}
      {{- end }}
      {{- if $.Values.initContainers }}
      initContainers:
        {{- toYaml $.Values.initContainers | nindent 8 }}
      {{- end }}
      containers:
      - name: {{ $component }}
        {{- if index $.Values (printf "securityContext%s" (title $component)) }}
        securityContext:
          {{- toYaml (index $.Values (printf "securityContext%s" (title $component))) | nindent 10 }}
        {{- else if $.Values.securityContext }}
        securityContext:
          {{- toYaml $.Values.securityContext | nindent 10 }}
        {{- end }}
        image: "{{ $componentConfig.repository }}:{{ $componentConfig.tag | default $.Chart.AppVersion }}"
        imagePullPolicy: {{ $componentConfig.pullPolicy | default "IfNotPresent" }}
        ports:
        - name: http
          containerPort: {{ index $.Values.service $component "targetPort" }}
          protocol: TCP
        {{- $componentEnv := index $.Values.env $component }}
        {{- if $componentEnv }}
        env:
        {{- include "portfolio-common.env" $componentEnv | nindent 8 }}
        {{- end }}
        {{- $startupProbe := index $.Values (printf "startupProbe%s" (title $component)) | default $.Values.startupProbe }}
        {{- if $startupProbe }}
        startupProbe:
          {{- toYaml $startupProbe | nindent 10 }}
        {{- end }}
        {{- $livenessProbe := index $.Values (printf "livenessProbe%s" (title $component)) | default $.Values.livenessProbe }}
        {{- if $livenessProbe }}
        livenessProbe:
          {{- toYaml $livenessProbe | nindent 10 }}
        {{- end }}
        {{- $readinessProbe := index $.Values (printf "readinessProbe%s" (title $component)) | default $.Values.readinessProbe }}
        {{- if $readinessProbe }}
        readinessProbe:
          {{- toYaml $readinessProbe | nindent 10 }}
        {{- end }}
        {{- $componentResources := index $.Values.resources $component }}
        {{- if $componentResources }}
        resources:
          {{- toYaml $componentResources | nindent 10 }}
        {{- end }}
        {{- if $.Values.volumeMounts }}
        volumeMounts:
          {{- toYaml $.Values.volumeMounts | nindent 10 }}
        {{- end }}
      {{- if $.Values.volumes }}
      volumes:
        {{- toYaml $.Values.volumes | nindent 8 }}
      {{- end }}
      {{- if $.Values.topologySpreadConstraints }}
      {{- if $.Values.topologySpreadConstraints.enabled }}
      topologySpreadConstraints:
        - maxSkew: {{ $.Values.topologySpreadConstraints.maxSkew | default 1 }}
          topologyKey: {{ $.Values.topologySpreadConstraints.topologyKey | default "kubernetes.io/hostname" }}
          whenUnsatisfiable: {{ $.Values.topologySpreadConstraints.whenUnsatisfiable | default "ScheduleAnyway" }}
          labelSelector:
            matchLabels:
              app: {{ include "portfolio-common.name" $ }}-{{ $component }}
      {{- end }}
      {{- end }}
      {{- /* Per-component scheduling (e.g. nodeSelectorClient) overrides the chart-wide value when the key is present, even if empty */}}
      {{- range $field := list "nodeSelector" "affinity" "tolerations" }}
      {{- $componentKey := printf "%s%s" $field (title $component) }}
      {{- $value := ternary (index $.Values $componentKey) (index $.Values $field) (hasKey $.Values $componentKey) }}
      {{- with $value }}
      {{ $field }}:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- end }}
{{- end }}
